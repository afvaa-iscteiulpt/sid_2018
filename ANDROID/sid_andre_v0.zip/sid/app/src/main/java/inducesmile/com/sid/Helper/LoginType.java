package inducesmile.com.sid.Helper;

public enum LoginType {
    VALID, INVALID;
}
