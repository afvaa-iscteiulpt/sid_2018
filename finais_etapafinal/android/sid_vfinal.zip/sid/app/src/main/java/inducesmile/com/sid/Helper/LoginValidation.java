package inducesmile.com.sid.Helper;

public enum LoginValidation {
    VALID, INVALID;
}
